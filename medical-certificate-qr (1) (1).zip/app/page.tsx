"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { User, FileText, Printer, Building2, Stethoscope } from "lucide-react"
import QRCode from "qrcode"

interface CertificateData {
  // Service Information
  prestadorServicios: string
  ordenServicio: string
  tipoEvaluacion: string
  fechaEmision: string

  // Patient Information
  identificacion: string
  nombrePaciente: string
  cargoDesempenar: string
  empresaUsuaria: string

  // Medical Evaluation
  conceptoPreIngreso: string
  conceptoOsteomuscular: string
  restriccionesMedicas: string

  // Validation
  codigoValidacion: string
}

export default function OccupationalMedicalCertificate() {
  const [certificateData, setCertificateData] = useState<CertificateData>({
    prestadorServicios: "SOMEB DE NARIÑO IPS",
    ordenServicio: "",
    tipoEvaluacion: "Pre-Ingreso, Osteomuscular",
    fechaEmision: new Date().toISOString().replace("T", " ").substring(0, 19),
    identificacion: "",
    nombrePaciente: "",
    cargoDesempenar: "",
    empresaUsuaria: "",
    conceptoPreIngreso: "Condiciones de salud acordes con los requerimientos del perfil del cargo.",
    conceptoOsteomuscular:
      "Con patología(s) osteomuscular(es) que no interfiere(n) con su capacidad laboral ni con los requerimientos del perfil del cargo.",
    restriccionesMedicas: "No",
    codigoValidacion: "",
  })

  const [qrCodeUrl, setQrCodeUrl] = useState<string>("")
  const [showCertificate, setShowCertificate] = useState(false)

  const handleInputChange = (field: keyof CertificateData, value: string) => {
    setCertificateData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const generateValidationCode = () => {
    const chars = "abcdefghijklmnopqrstuvwxyz0123456789"
    let result = ""
    for (let i = 0; i < 32; i++) {
      if (i > 0 && i % 4 === 0) result += "-"
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return result
  }

  const generateCertificate = async () => {
    const validationCode = generateValidationCode()
    setCertificateData((prev) => ({ ...prev, codigoValidacion: validationCode }))

    const qrData = JSON.stringify({
      ordenServicio: certificateData.ordenServicio,
      identificacion: certificateData.identificacion,
      codigoValidacion: validationCode,
      fechaEmision: certificateData.fechaEmision,
    })

    try {
      const qrCodeDataUrl = await QRCode.toDataURL(qrData, {
        width: 150,
        margin: 1,
        color: {
          dark: "#000000",
          light: "#FFFFFF",
        },
      })
      setQrCodeUrl(qrCodeDataUrl)
      setShowCertificate(true)
    } catch (error) {
      console.error("Error generating QR code:", error)
    }
  }

  const handlePrint = () => {
    window.print()
  }

  const isFormValid = () => {
    return (
      certificateData.ordenServicio &&
      certificateData.identificacion &&
      certificateData.nombrePaciente &&
      certificateData.cargoDesempenar &&
      certificateData.empresaUsuaria
    )
  }

  if (showCertificate) {
    return (
      <div className="min-h-screen bg-gray-100">
        {/* Print styles */}
        <style jsx global>{`
          @media print {
            body { margin: 0; background: white !important; }
            .no-print { display: none !important; }
            .print-container { 
              width: 100%; 
              max-width: none; 
              margin: 0; 
              box-shadow: none;
              background: white;
            }
          }
        `}</style>

        {/* Print buttons */}
        <div className="no-print p-4 bg-white border-b">
          <div className="max-w-2xl mx-auto flex gap-4">
            <Button onClick={handlePrint} className="flex items-center gap-2">
              <Printer className="w-4 h-4" />
              Imprimir Certificado
            </Button>
            <Button variant="outline" onClick={() => setShowCertificate(false)} className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Editar Datos
            </Button>
          </div>
        </div>

        {/* Certificate */}
        <div className="print-container max-w-2xl mx-auto p-4 bg-white">
          <div className="bg-white border border-gray-300 rounded-lg overflow-hidden">
            {/* Header */}
            <div className="bg-white p-6 text-center border-b border-gray-200">
              <div className="flex items-center justify-center mb-4">
                <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mr-4">
                  <Stethoscope className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-blue-600">Simeon</h1>
                  <p className="text-sm text-gray-600">IPS</p>
                </div>
              </div>
              <p className="text-sm text-gray-600">Seguridad y Salud Laboral integrada con Tecnología</p>
            </div>

            {/* Document Type */}
            <div className="bg-green-100 p-3 text-center">
              <p className="text-sm text-gray-700 mb-1">Tipo Documento</p>
              <h2 className="text-lg font-bold text-green-800">CONCEPTO MÉDICO OCUPACIONAL</h2>
            </div>

            {/* Content */}
            <div className="p-6 space-y-4">
              {/* Service Information */}
              <div className="space-y-2">
                <div>
                  <span className="font-semibold text-gray-700">Prestador Servicios</span>
                  <p className="text-gray-900">{certificateData.prestadorServicios}</p>
                </div>
                <div>
                  <span className="font-semibold text-gray-700">Orden Servicio No.</span>
                  <p className="text-gray-900">{certificateData.ordenServicio}</p>
                </div>
                <div>
                  <span className="font-semibold text-gray-700">Tipo Evaluación - Énfasis</span>
                  <p className="text-gray-900">{certificateData.tipoEvaluacion}</p>
                </div>
                <div>
                  <span className="font-semibold text-gray-700">Fecha Emisión</span>
                  <p className="text-gray-900">{certificateData.fechaEmision}</p>
                </div>
              </div>

              <Separator />

              {/* Patient Information */}
              <div className="space-y-2">
                <div>
                  <span className="font-semibold text-gray-700">Identificación</span>
                  <p className="text-gray-900">
                    {certificateData.identificacion} - {certificateData.nombrePaciente}
                  </p>
                </div>
                <div>
                  <span className="font-semibold text-gray-700">Cargo a desempeñar</span>
                  <p className="text-gray-900">{certificateData.cargoDesempenar}</p>
                </div>
                <div>
                  <span className="font-semibold text-gray-700">Empresa Usuaria</span>
                  <p className="text-gray-900">{certificateData.empresaUsuaria}</p>
                </div>
              </div>

              <Separator />

              {/* Medical Concepts */}
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-gray-700 mb-2">Concepto Ocupacional:</h3>
                  <div className="space-y-3">
                    <div>
                      <span className="font-semibold text-gray-700">Pre-Ingreso</span>
                      <p className="text-gray-900 text-sm leading-relaxed">{certificateData.conceptoPreIngreso}</p>
                    </div>
                    <div>
                      <span className="font-semibold text-gray-700">Osteomuscular</span>
                      <p className="text-gray-900 text-sm leading-relaxed">{certificateData.conceptoOsteomuscular}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <span className="font-semibold text-gray-700">Restricciones Médicas</span>
                  <p className="text-gray-900">{certificateData.restriccionesMedicas}</p>
                </div>
              </div>

              <Separator />

              {/* Validation Code */}
              <div className="text-center space-y-2">
                <p className="font-semibold text-red-600">Código Validación</p>
                <p className="text-sm text-red-500 font-mono break-all">{certificateData.codigoValidacion}</p>

                {qrCodeUrl && (
                  <div className="flex justify-center mt-4">
                    <img src={qrCodeUrl || "/placeholder.svg"} alt="QR Code" className="border border-gray-300" />
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="text-center text-xs text-gray-500 pt-4 border-t border-gray-200">
                <p>2025 ® Derechos reservados.</p>
                <p className="text-blue-600">www.simeon.com.co</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <Card>
          <CardHeader>
            <div className="text-center">
              <div className="flex items-center justify-center mb-4">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mr-3">
                  <Stethoscope className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-blue-600">Simeon IPS</h1>
                  <p className="text-sm text-gray-600">Concepto Médico Ocupacional</p>
                </div>
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            {/* Service Information */}
            <div>
              <h3 className="text-lg font-semibold text-blue-700 mb-4 flex items-center gap-2">
                <Building2 className="w-5 h-5" />
                Información del Servicio
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="prestadorServicios">Prestador de Servicios</Label>
                  <Input
                    id="prestadorServicios"
                    value={certificateData.prestadorServicios}
                    onChange={(e) => handleInputChange("prestadorServicios", e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="ordenServicio">Orden de Servicio No. *</Label>
                  <Input
                    id="ordenServicio"
                    value={certificateData.ordenServicio}
                    onChange={(e) => handleInputChange("ordenServicio", e.target.value)}
                    placeholder="Ej: 992742"
                  />
                </div>
                <div>
                  <Label htmlFor="tipoEvaluacion">Tipo de Evaluación</Label>
                  <Select
                    value={certificateData.tipoEvaluacion}
                    onValueChange={(value) => handleInputChange("tipoEvaluacion", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pre-Ingreso, Osteomuscular">Pre-Ingreso, Osteomuscular</SelectItem>
                      <SelectItem value="Pre-Ingreso">Pre-Ingreso</SelectItem>
                      <SelectItem value="Periódico">Periódico</SelectItem>
                      <SelectItem value="Post-Incapacidad">Post-Incapacidad</SelectItem>
                      <SelectItem value="Retiro">Retiro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="fechaEmision">Fecha de Emisión</Label>
                  <Input
                    id="fechaEmision"
                    type="datetime-local"
                    value={certificateData.fechaEmision}
                    onChange={(e) => handleInputChange("fechaEmision", e.target.value)}
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Patient Information */}
            <div>
              <h3 className="text-lg font-semibold text-blue-700 mb-4 flex items-center gap-2">
                <User className="w-5 h-5" />
                Información del Paciente
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="identificacion">Identificación *</Label>
                  <Input
                    id="identificacion"
                    value={certificateData.identificacion}
                    onChange={(e) => handleInputChange("identificacion", e.target.value)}
                    placeholder="Ej: 1089485***"
                  />
                </div>
                <div>
                  <Label htmlFor="nombrePaciente">Nombre del Paciente *</Label>
                  <Input
                    id="nombrePaciente"
                    value={certificateData.nombrePaciente}
                    onChange={(e) => handleInputChange("nombrePaciente", e.target.value)}
                    placeholder="Apellido del paciente"
                  />
                </div>
                <div>
                  <Label htmlFor="cargoDesempenar">Cargo a Desempeñar *</Label>
                  <Input
                    id="cargoDesempenar"
                    value={certificateData.cargoDesempenar}
                    onChange={(e) => handleInputChange("cargoDesempenar", e.target.value)}
                    placeholder="Ej: ENFERMERA JEFE"
                  />
                </div>
                <div>
                  <Label htmlFor="empresaUsuaria">Empresa Usuaria *</Label>
                  <Input
                    id="empresaUsuaria"
                    value={certificateData.empresaUsuaria}
                    onChange={(e) => handleInputChange("empresaUsuaria", e.target.value)}
                    placeholder="Nombre de la empresa"
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Medical Evaluation */}
            <div>
              <h3 className="text-lg font-semibold text-blue-700 mb-4 flex items-center gap-2">
                <Stethoscope className="w-5 h-5" />
                Concepto Médico
              </h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="conceptoPreIngreso">Concepto Pre-Ingreso</Label>
                  <Textarea
                    id="conceptoPreIngreso"
                    value={certificateData.conceptoPreIngreso}
                    onChange={(e) => handleInputChange("conceptoPreIngreso", e.target.value)}
                    rows={2}
                  />
                </div>
                <div>
                  <Label htmlFor="conceptoOsteomuscular">Concepto Osteomuscular</Label>
                  <Textarea
                    id="conceptoOsteomuscular"
                    value={certificateData.conceptoOsteomuscular}
                    onChange={(e) => handleInputChange("conceptoOsteomuscular", e.target.value)}
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="restriccionesMedicas">Restricciones Médicas</Label>
                  <Select
                    value={certificateData.restriccionesMedicas}
                    onValueChange={(value) => handleInputChange("restriccionesMedicas", value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="No">No</SelectItem>
                      <SelectItem value="Sí">Sí</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <Separator />

            <div className="text-center">
              <Button onClick={generateCertificate} disabled={!isFormValid()} className="px-8 py-3 text-lg">
                Generar Certificado Médico Ocupacional
              </Button>
              {!isFormValid() && <p className="text-sm text-red-600 mt-2">* Complete todos los campos obligatorios</p>}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
